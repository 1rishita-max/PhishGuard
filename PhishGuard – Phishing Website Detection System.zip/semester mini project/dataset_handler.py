"""
dataset_handler.py  (UPDATED — UCI Real Dataset)
-------------------------------------------------
Downloads and uses the UCI Phishing Websites Dataset (11,055 real samples).
Falls back to the synthetic dataset only if download fails.
"""

import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DATASET_PATH = os.path.join(os.path.dirname(__file__), "datasets", "phishing_dataset.csv")

# ── UCI feature names (exact order from the dataset) ──────────────────────
FEATURE_NAMES = [
    "having_IP_Address",
    "URL_Length",
    "Shortining_Service",
    "having_At_Symbol",
    "double_slash_redirecting",
    "Prefix_Suffix",
    "having_Sub_Domain",
    "SSLfinal_State",
    "Domain_registeration_length",
    "Favicon",
    "port",
    "HTTPS_token",
    "Request_URL",
    "URL_of_Anchor",
    "Links_in_tags",
    "SFH",
    "Submitting_to_email",
    "Abnormal_URL",
    "Redirect",
    "on_mouseover",
    "RightClick",
    "popUpWidnow",
    "Iframe",
    "age_of_domain",
    "DNSRecord",
    "web_traffic",
    "Page_Rank",
    "Google_Index",
    "Links_pointing_to_page",
    "Statistical_report",
]


def download_uci_dataset(save: bool = True) -> pd.DataFrame:
    """
    Download the UCI Phishing Websites Dataset using ucimlrepo.
    Returns a DataFrame with FEATURE_NAMES columns + 'label' column.
    Label: -1 = phishing, 1 = legitimate
    """
    print("[dataset_handler] Downloading UCI Phishing Dataset (11,055 real samples)...")
    try:
        from ucimlrepo import fetch_ucirepo
        phishing_websites = fetch_ucirepo(id=327)
        X = phishing_websites.data.features   # DataFrame with 30 features
        y = phishing_websites.data.targets    # DataFrame with 'Result' column

        # Rename columns to our standard feature names if needed
        X.columns = FEATURE_NAMES

        # Target: UCI uses -1 (phishing) and 1 (legitimate)
        df = X.copy()
        df["label"] = y.values.ravel()

        # Ensure label is -1/1
        df["label"] = df["label"].astype(int)

        print(f"[dataset_handler] Downloaded {len(df)} samples.")
        print(f"  Phishing  : {(df['label'] == -1).sum()}")
        print(f"  Legitimate: {(df['label'] ==  1).sum()}")

        if save:
            os.makedirs(os.path.dirname(DATASET_PATH), exist_ok=True)
            df.to_csv(DATASET_PATH, index=False)
            print(f"[dataset_handler] Saved to: {DATASET_PATH}")

        return df

    except Exception as e:
        print(f"[dataset_handler] UCI download failed: {e}")
        print("[dataset_handler] Falling back to synthetic dataset...")
        return _generate_synthetic(save=save)


def _generate_synthetic(n_samples: int = 2000, save: bool = True) -> pd.DataFrame:
    """Generate a synthetic fallback dataset matching UCI feature schema."""
    import random
    random.seed(42)
    np.random.seed(42)

    def legit():
        return {f: random.choice([1, 1, 1, 0]) for f in FEATURE_NAMES}

    def phish():
        return {f: random.choice([-1, -1, 0]) for f in FEATURE_NAMES}

    half = n_samples // 2
    records = [{**legit(), "label": 1} for _ in range(half)] + \
              [{**phish(), "label": -1} for _ in range(half)]

    df = pd.DataFrame(records).sample(frac=1, random_state=42).reset_index(drop=True)
    if save:
        os.makedirs(os.path.dirname(DATASET_PATH), exist_ok=True)
        df.to_csv(DATASET_PATH, index=False)
    return df


def load_dataset(path: str = DATASET_PATH) -> pd.DataFrame:
    """Load dataset. Downloads UCI if not cached."""
    if not os.path.exists(path):
        print("[dataset_handler] No cached dataset found. Downloading from UCI...")
        return download_uci_dataset(save=True)
    df = pd.read_csv(path)
    print(f"[dataset_handler] Loaded cached dataset: {len(df)} samples from {path}")
    return df


def explore_dataset(df: pd.DataFrame):
    """Print EDA summary."""
    print("\n========== Dataset Summary ==========")
    print(f"Shape : {df.shape}")
    print(f"Labels:\n{df['label'].value_counts().to_string()}")
    phish_pct = (df['label'] == -1).mean() * 100
    print(f"Phishing: {phish_pct:.1f}%  |  Legitimate: {100-phish_pct:.1f}%")
    print(f"Missing : {df.isnull().sum().sum()} values")
    print("=====================================\n")


def prepare_data(df: pd.DataFrame, test_size: float = 0.2, scale: bool = True):
    """
    Split into train/test sets and scale.
    Returns: X_train, X_test, y_train, y_test, scaler
    """
    X = df[FEATURE_NAMES].values
    y = df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )

    scaler = None
    if scale:
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test  = scaler.transform(X_test)

    print(f"[dataset_handler] Train: {X_train.shape} | Test: {X_test.shape}")
    return X_train, X_test, y_train, y_test, scaler


if __name__ == "__main__":
    df = download_uci_dataset()
    explore_dataset(df)
