"""
ml_model.py
-----------
Train, evaluate, and save phishing detection ML models.
Primary: Random Forest. Also tests Logistic Regression & Decision Tree.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)

MODEL_PATH  = os.path.join(os.path.dirname(__file__), "models", "phishing_model.pkl")
SCALER_PATH = os.path.join(os.path.dirname(__file__), "models", "scaler.pkl")


def get_models() -> dict:
    """Return dict of models to compare."""
    return {
        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            max_depth=20,
            min_samples_split=4,
            random_state=42,
            n_jobs=-1
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=15,
            random_state=42
        ),
        "Logistic Regression": LogisticRegression(
            max_iter=1000,
            random_state=42
        ),
    }


def train_and_evaluate(X_train, X_test, y_train, y_test) -> dict:
    """
    Train all models and return evaluation metrics for each.
    Returns: dict of {model_name: {metric: value, model: fitted_model}}
    """
    models = get_models()
    results = {}

    for name, model in models.items():
        print(f"\n[ml_model] Training: {name} ...")
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        acc  = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds, pos_label=-1, zero_division=0)
        rec  = recall_score(y_test, preds, pos_label=-1, zero_division=0)
        f1   = f1_score(y_test, preds, pos_label=-1, zero_division=0)
        cm   = confusion_matrix(y_test, preds)

        results[name] = {
            "accuracy":  round(acc * 100, 2),
            "precision": round(prec * 100, 2),
            "recall":    round(rec * 100, 2),
            "f1_score":  round(f1 * 100, 2),
            "confusion_matrix": cm,
            "model":     model,
        }

        print(f"  Accuracy : {acc*100:.2f}%")
        print(f"  Precision: {prec*100:.2f}%")
        print(f"  Recall   : {rec*100:.2f}%")
        print(f"  F1-Score : {f1*100:.2f}%")
        print(f"\n{classification_report(y_test, preds, target_names=['Phishing', 'Legitimate'])}")

    return results


def save_best_model(results: dict, scaler=None):
    """Save the highest-accuracy model."""
    best_name = max(results, key=lambda k: results[k]["accuracy"])
    best = results[best_name]

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(best["model"], MODEL_PATH)
    print(f"\n[ml_model] Best model saved: '{best_name}' ({best['accuracy']}%) -> {MODEL_PATH}")

    if scaler is not None:
        joblib.dump(scaler, SCALER_PATH)
        print(f"[ml_model] Scaler saved -> {SCALER_PATH}")

    return best_name


def load_model():
    """Load saved model from disk."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run train.py first.")
    return joblib.load(MODEL_PATH)


def load_scaler():
    """Load saved scaler from disk."""
    if not os.path.exists(SCALER_PATH):
        return None
    return joblib.load(SCALER_PATH)


def get_feature_importances(feature_names: list) -> pd.DataFrame:
    """Return feature importances from saved Random Forest model."""
    model = load_model()
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
        df = pd.DataFrame({
            "feature": feature_names,
            "importance": importances
        }).sort_values("importance", ascending=False)
        return df
    return pd.DataFrame()


if __name__ == "__main__":
    from dataset_handler import load_dataset, prepare_data, FEATURE_NAMES
    df = load_dataset()
    X_train, X_test, y_train, y_test, scaler = prepare_data(df)
    results = train_and_evaluate(X_train, X_test, y_train, y_test)
    save_best_model(results, scaler)
