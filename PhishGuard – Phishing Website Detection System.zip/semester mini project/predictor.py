"""
predictor.py
------------
Real-time URL phishing prediction using the trained model.
Usage:
    python predictor.py --url "https://example.com"
    python predictor.py --url "http://paypa1-secure.xyz/login"
"""

import sys
import argparse
import os
import numpy as np

from feature_extractor import FeatureExtractor
from ml_model import load_model, load_scaler
from dataset_handler import FEATURE_NAMES


class PhishingPredictor:
    """Predict whether a URL is phishing or legitimate."""

    def __init__(self):
        self.extractor = FeatureExtractor()
        self.model     = load_model()
        self.scaler    = load_scaler()

    def predict(self, url: str) -> dict:
        """
        Predict phishing status for a URL.
        Returns result dict with verdict, confidence, features, and risk analysis.
        """
        if not url.startswith(("http://", "https://")):
            url = "http://" + url

        # Extract features
        feature_dict = self.extractor.extract_features(url)
        feature_vector = np.array(
            [feature_dict[name] for name in FEATURE_NAMES]
        ).reshape(1, -1)

        # Scale
        if self.scaler:
            feature_vector = self.scaler.transform(feature_vector)

        # Predict
        prediction = self.model.predict(feature_vector)[0]  # -1=phishing, 1=legitimate
        probabilities = self.model.predict_proba(feature_vector)[0]  # [p_phishing, p_legit]

        # Map to readable output
        is_phishing = (prediction == -1)

        if hasattr(self.model, "classes_"):
            classes = list(self.model.classes_)
            if -1 in classes:
                phish_prob = probabilities[classes.index(-1)] * 100
            else:
                phish_prob = (1 - probabilities[0]) * 100
        else:
            phish_prob = 50.0

        legit_prob = 100 - phish_prob

        # Risk score (0–100)
        risk_score = round(phish_prob, 1)

        # Determine risk level
        if risk_score >= 70:
            risk_level = "HIGH"
            risk_color = "danger"
        elif risk_score >= 40:
            risk_level = "MEDIUM"
            risk_color = "warning"
        else:
            risk_level = "LOW"
            risk_color = "success"

        # Identify suspicious features
        suspicious_features = {
            k: v for k, v in feature_dict.items() if v == -1
        }
        neutral_features = {
            k: v for k, v in feature_dict.items() if v == 0
        }
        safe_features = {
            k: v for k, v in feature_dict.items() if v == 1
        }

        return {
            "url":                url,
            "verdict":            "PHISHING" if is_phishing else "LEGITIMATE",
            "is_phishing":        is_phishing,
            "risk_score":         risk_score,
            "risk_level":         risk_level,
            "risk_color":         risk_color,
            "phish_probability":  round(phish_prob, 1),
            "legit_probability":  round(legit_prob, 1),
            "features":           feature_dict,
            "suspicious_features": suspicious_features,
            "neutral_features":   neutral_features,
            "safe_features":      safe_features,
            "total_features":     len(feature_dict),
            "suspicious_count":   len(suspicious_features),
            "safe_count":         len(safe_features),
        }

    def describe_result(self, result: dict) -> str:
        """Pretty-print prediction result to console."""
        sep = "=" * 60
        lines = [
            sep,
            f"  URL Analysis Report",
            sep,
            f"  URL        : {result['url']}",
            f"  Verdict    : {'[!] PHISHING' if result['is_phishing'] else '[OK] LEGITIMATE'}",
            f"  Risk Score : {result['risk_score']}% ({result['risk_level']} RISK)",
            f"  Confidence : Phishing={result['phish_probability']}% | Legit={result['legit_probability']}%",
            "",
            f"  Feature Summary:",
            f"    [+] Safe       : {result['safe_count']} features",
            f"    [!] Suspicious : {result['suspicious_count']} features",
            f"    [-] Neutral    : {len(result['neutral_features'])} features",
            "",
            "  Suspicious Signals:",
        ]
        for feat in result["suspicious_features"]:
            lines.append(f"    [X] {feat.replace('_', ' ').title()}")
        lines.append(sep)
        return "\n".join(lines)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Phishing URL Detector")
    parser.add_argument("--url", type=str, required=True, help="URL to analyze")
    args = parser.parse_args()

    predictor = PhishingPredictor()
    result = predictor.predict(args.url)
    print(predictor.describe_result(result))
