"""
app.py
------
Flask web application for Phishing Website Detection.
Run: python app.py
Then open: http://127.0.0.1:5000
"""

import os
import json
import traceback
from flask import Flask, render_template, request, jsonify, redirect, url_for
from predictor import PhishingPredictor
from visualizer import (
    plot_confusion_matrix, plot_model_comparison,
    plot_feature_importance, plot_dataset_distribution
)
from dataset_handler import load_dataset, prepare_data, FEATURE_NAMES
from ml_model import load_model, train_and_evaluate, save_best_model, load_scaler

app = Flask(__name__)
app.secret_key = "phishing_detector_2024"

# ─────────────────────────── Init Predictor ───────────────────────────────
predictor = None

def get_predictor():
    global predictor
    if predictor is None:
        try:
            predictor = PhishingPredictor()
        except FileNotFoundError:
            return None
    return predictor


# ─────────────────────────────── Routes ──────────────────────────────────

@app.route("/")
def index():
    """Home page with URL input."""
    model_ready = get_predictor() is not None
    return render_template("index.html", model_ready=model_ready)


@app.route("/predict", methods=["POST"])
def predict():
    """Analyze a URL and return the result."""
    url = request.form.get("url", "").strip()
    if not url:
        return redirect(url_for("index"))

    pred = get_predictor()
    if pred is None:
        return render_template("error.html",
            message="Model not trained yet. Please run: python train.py")

    try:
        result = pred.predict(url)
        return render_template("result.html", result=result)
    except Exception as e:
        return render_template("error.html",
            message=f"Analysis failed: {str(e)}")


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """JSON API endpoint for URL prediction."""
    data = request.get_json()
    url = (data or {}).get("url", "").strip()
    if not url:
        return jsonify({"error": "No URL provided"}), 400

    pred = get_predictor()
    if pred is None:
        return jsonify({"error": "Model not trained. Run: python train.py"}), 503

    try:
        result = pred.predict(url)
        # Remove non-serializable items
        result.pop("features", None)
        result.pop("suspicious_features", None)
        result.pop("neutral_features", None)
        result.pop("safe_features", None)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/dashboard")
def dashboard():
    """Model analytics and charts dashboard."""
    model_ready = get_predictor() is not None

    # Load charts from reports (base64)
    reports_dir = os.path.join(os.path.dirname(__file__), "reports")
    charts = {}

    def load_chart(filename):
        path = os.path.join(reports_dir, filename)
        if os.path.exists(path):
            import base64
            with open(path, "rb") as f:
                return base64.b64encode(f.read()).decode("utf-8")
        return None

    charts["confusion_matrix"]    = load_chart("confusion_matrix.png")
    charts["model_comparison"]    = load_chart("model_comparison.png")
    charts["feature_importance"]  = load_chart("feature_importance.png")
    charts["dataset_distribution"]= load_chart("dataset_distribution.png")

    # Load model metrics from last training (stored in reports/metrics.json if exists)
    metrics = {}
    metrics_path = os.path.join(reports_dir, "metrics.json")
    if os.path.exists(metrics_path):
        with open(metrics_path) as f:
            metrics = json.load(f)

    return render_template("dashboard.html",
        model_ready=model_ready, charts=charts, metrics=metrics)


@app.route("/about")
def about():
    """About page with project info."""
    return render_template("about.html")


@app.route("/train", methods=["POST"])
def train_model():
    """Trigger model training from the web UI."""
    try:
        df = load_dataset()
        X_train, X_test, y_train, y_test, scaler = prepare_data(df)
        results = train_and_evaluate(X_train, X_test, y_train, y_test)
        best_name = save_best_model(results, scaler)

        # Save metrics to JSON for dashboard
        metrics = {}
        for name, r in results.items():
            metrics[name] = {
                "accuracy":  r["accuracy"],
                "precision": r["precision"],
                "recall":    r["recall"],
                "f1_score":  r["f1_score"],
            }
        reports_dir = os.path.join(os.path.dirname(__file__), "reports")
        os.makedirs(reports_dir, exist_ok=True)
        with open(os.path.join(reports_dir, "metrics.json"), "w") as f:
            json.dump(metrics, f, indent=2)

        global predictor
        predictor = None  # Reset so it reloads on next request

        # Regenerate charts
        best_model = results[best_name]["model"]
        y_pred = best_model.predict(X_test)
        plot_confusion_matrix(y_test, y_pred, best_name)
        plot_model_comparison(results)
        plot_dataset_distribution(list(df["label"]))
        if hasattr(best_model, "feature_importances_"):
            plot_feature_importance(FEATURE_NAMES, list(best_model.feature_importances_))

        return jsonify({
            "success": True,
            "best_model": best_name,
            "accuracy": results[best_name]["accuracy"]
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


if __name__ == "__main__":
    print("\n" + "=" * 55)
    print("  [*] Phishing Website Detection System")
    print("=" * 55)
    model_path = os.path.join(os.path.dirname(__file__), "models", "phishing_model.pkl")
    if not os.path.exists(model_path):
        print("  [!] Model not found! Run: python train.py first")
    else:
        print("  [OK] Model loaded. Ready to detect phishing URLs!")
    print("  [>] Open: http://127.0.0.1:5000")
    print("=" * 55 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
