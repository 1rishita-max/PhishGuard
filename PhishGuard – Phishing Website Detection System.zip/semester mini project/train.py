"""
train.py  (UPDATED — UCI Real Dataset)
---------------------------------------
Training pipeline using the real UCI Phishing Websites Dataset (11,055 samples).
Run: python train.py
"""

import os
import sys
import json

print("=" * 62)
print("  Phishing Detection — Training Pipeline (UCI Real Dataset)")
print("=" * 62)

# ── Step 1: Download / Load Real Dataset ─────────────────────────────────
print("\n[Step 1/4] Loading UCI Phishing Dataset...")

DATASET_PATH = os.path.join(os.path.dirname(__file__), "datasets", "phishing_dataset.csv")

# Delete old synthetic dataset to force fresh UCI download
if os.path.exists(DATASET_PATH):
    import pandas as pd
    _df_check = pd.read_csv(DATASET_PATH)
    is_synthetic = len(_df_check) <= 2000  # old synthetic had 2000 rows
    if is_synthetic:
        print("  Old synthetic dataset detected — replacing with real UCI data...")
        os.remove(DATASET_PATH)

from dataset_handler import download_uci_dataset, load_dataset, explore_dataset, prepare_data, FEATURE_NAMES

# Try to download; if already cached and large enough, just load it
if not os.path.exists(DATASET_PATH):
    df = download_uci_dataset(save=True)
else:
    df = load_dataset(DATASET_PATH)
    if len(df) < 5000:  # Small = likely synthetic leftover
        print("  Re-downloading UCI dataset for better accuracy...")
        df = download_uci_dataset(save=True)

explore_dataset(df)

# ── Step 2: Prepare Data ─────────────────────────────────────────────────
print("\n[Step 2/4] Preparing Training & Test Sets...")
X_train, X_test, y_train, y_test, scaler = prepare_data(df, test_size=0.2, scale=True)

# ── Step 3: Train Models ─────────────────────────────────────────────────
print("\n[Step 3/4] Training Models on Real Data...")
from ml_model import train_and_evaluate, save_best_model

results = train_and_evaluate(X_train, X_test, y_train, y_test)
best_model_name = save_best_model(results, scaler)

# Save metrics.json for dashboard
metrics = {}
for name, r in results.items():
    metrics[name] = {
        "accuracy":  r["accuracy"],
        "precision": r["precision"],
        "recall":    r["recall"],
        "f1_score":  r["f1_score"],
    }
reports_dir = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(reports_dir, exist_ok=True)
with open(os.path.join(reports_dir, "metrics.json"), "w") as f:
    json.dump(metrics, f, indent=2)

# ── Step 4: Generate Charts ───────────────────────────────────────────────
print("\n[Step 4/4] Generating Visualizations...")
from visualizer import (
    plot_confusion_matrix, plot_model_comparison,
    plot_feature_importance, plot_dataset_distribution
)

best_model = results[best_model_name]["model"]
y_pred = best_model.predict(X_test)

plot_confusion_matrix(y_test, y_pred, model_name=best_model_name)
plot_model_comparison(results)
plot_dataset_distribution(list(df["label"]))
if hasattr(best_model, "feature_importances_"):
    plot_feature_importance(FEATURE_NAMES, list(best_model.feature_importances_))

# ── Summary ───────────────────────────────────────────────────────────────
print("\n" + "=" * 62)
print("  [OK] Training Complete on REAL UCI Dataset!")
print(f"  Dataset    : {len(df):,} real-world samples")
print(f"  Best Model : {best_model_name}")
print(f"  Accuracy   : {results[best_model_name]['accuracy']}%")
print(f"  Precision  : {results[best_model_name]['precision']}%")
print(f"  Recall     : {results[best_model_name]['recall']}%")
print(f"  F1-Score   : {results[best_model_name]['f1_score']}%")
print("  Model saved: models/phishing_model.pkl")
print("  Charts saved: reports/")
print("\n  Run: python app.py  ->  Open http://127.0.0.1:5000")
print("=" * 62)
