"""
feature_extractor.py  (UPDATED — UCI-aligned features)
-------------------------------------------------------
Extracts the same 30 features used by the UCI Phishing Websites Dataset,
in the exact same order, using -1/0/1 encoding.
This ensures the real-time predictor matches the training data distribution.

UCI Feature Encoding:
  -1 = Phishing / Suspicious
   0 = Suspicious (neutral / uncertain)
   1 = Legitimate / Safe
"""

import re
import socket
import ssl
import urllib.parse

# ── Feature names match UCI exactly ──
FEATURE_NAMES = [
    "having_IP_Address",
    "URL_Length",
    "Shortining_Service",
    "having_At_Symbol",
    "double_slash_redirecting",
    "Prefix_Suffix",
    "having_Sub_Domain",
    "SSLfinal_State",
    "Domain_registeration_length",
    "Favicon",
    "port",
    "HTTPS_token",
    "Request_URL",
    "URL_of_Anchor",
    "Links_in_tags",
    "SFH",
    "Submitting_to_email",
    "Abnormal_URL",
    "Redirect",
    "on_mouseover",
    "RightClick",
    "popUpWidnow",
    "Iframe",
    "age_of_domain",
    "DNSRecord",
    "web_traffic",
    "Page_Rank",
    "Google_Index",
    "Links_pointing_to_page",
    "Statistical_report",
]

# Known shortening services
SHORTENERS = [
    "bit.ly", "goo.gl", "tinyurl.com", "ow.ly", "t.co", "is.gd",
    "buff.ly", "adf.ly", "bit.do", "mcaf.ee", "su.pr", "dlvr.it",
    "tr.im", "cli.gs", "shorturl.at", "tiny.cc", "rb.gy", "cutt.ly"
]

# Suspicious TLDs used in phishing
SUSPICIOUS_TLDS = [
    ".xyz", ".tk", ".cf", ".ml", ".ga", ".gq", ".top", ".click",
    ".online", ".site", ".info", ".biz", ".ws", ".pw", ".cc", ".uno"
]

# Typosquat targets: maps real brand → suspicious variants
TYPOSQUAT_MAP = {
    "paypal": ["paypa1", "paypai", "payp4l", "paypall"],
    "google": ["g00gle", "googie", "gogle", "g0ogle"],
    "apple":  ["app1e", "appl3", "aple"],
    "amazon": ["amaz0n", "arnazon", "arnaz0n"],
    "facebook": ["faceb00k", "faceboook", "facbook"],
    "microsoft": ["micros0ft", "micr0soft", "mlcrosoft"],
    "instagram": ["1nstagram", "instaqram"],
    "netflix": ["netf1ix", "netfl1x", "netlfix"],
    "ebay":   ["ebay-",  "e-bay",  "3bay"],
    "bank":   ["b4nk",   "banck",  "bnak"],
}

SENSITIVE_KEYWORDS = [
    "secure", "account", "update", "login", "signin", "banking",
    "confirm", "password", "verify", "webscr", "ebayisapi", "paypal",
    "submit", "redirect", "cmd", "session", "token", "recover",
]


class FeatureExtractor:
    """
    Extracts the 30 UCI-aligned features from a URL.
    Some features that require fetching the page (iframe, onmouseover, etc.)
    are estimated from URL patterns alone — consistent with how the model was
    trained on the UCI dataset feature distributions.
    """

    def __init__(self):
        pass

    # ── Feature 1 ──────────────────────────────────────────────────────────
    def _having_ip_address(self, url: str) -> int:
        """IP address in URL = phishing (-1), else legitimate (1)."""
        ip_pattern = re.compile(
            r"((\d{1,3}\.){3}\d{1,3})"            # IPv4
            r"|(0x[0-9a-fA-F]{2}\.){3}0x[0-9a-fA-F]{2}"  # Hex
            r"|\d{10,}"                             # Integer IP
        )
        return -1 if ip_pattern.search(url) else 1

    # ── Feature 2 ──────────────────────────────────────────────────────────
    def _url_length(self, url: str) -> int:
        """URL length: <54 -> 1, 54-75 -> 0, >75 -> -1."""
        n = len(url)
        if n < 54:   return 1
        if n <= 75:  return 0
        return -1

    # ── Feature 3 ──────────────────────────────────────────────────────────
    def _shortining_service(self, url: str) -> int:
        """URL shortening service: yes -> -1, no -> 1."""
        for s in SHORTENERS:
            if s in url.lower():
                return -1
        return 1

    # ── Feature 4 ──────────────────────────────────────────────────────────
    def _having_at_symbol(self, url: str) -> int:
        """@ symbol in URL forces browser to ignore prefix. Phishing = -1."""
        return -1 if "@" in url else 1

    # ── Feature 5 ──────────────────────────────────────────────────────────
    def _double_slash_redirecting(self, url: str) -> int:
        """'//' after position 7 means redirection = phishing."""
        pos = url.rfind("//")
        return -1 if pos > 7 else 1

    # ── Feature 6 ──────────────────────────────────────────────────────────
    def _prefix_suffix(self, url: str) -> int:
        """'-' in domain name = phishing (-1), else legitimate (1)."""
        try:
            domain = urllib.parse.urlparse(url).netloc
            return -1 if "-" in domain else 1
        except Exception:
            return -1

    # ── Feature 7 ──────────────────────────────────────────────────────────
    def _having_sub_domain(self, url: str) -> int:
        """
        Subdomain count:
          1 dot in domain (e.g. google.com)        -> 1
          2 dots (e.g. support.google.com)          -> 0
          3+ dots                                   -> -1
        """
        try:
            netloc = urllib.parse.urlparse(url).netloc
            domain = netloc.replace("www.", "")
            dots = domain.count(".")
            if dots == 1:   return 1
            if dots == 2:   return 0
            return -1
        except Exception:
            return -1

    # ── Feature 8 ──────────────────────────────────────────────────────────
    def _ssl_final_state(self, url: str) -> int:
        """
        SSL certificate check:
          Valid HTTPS               -> 1
          HTTPS but cert error      -> 0
          Not HTTPS                 -> -1
        """
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https":
            return -1
        try:
            hostname = parsed.netloc.split(":")[0]
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as s:
                s.settimeout(3)
                s.connect((hostname, 443))
            return 1
        except ssl.SSLCertVerificationError:
            return 0
        except Exception:
            return 0

    # ── Feature 9 ──────────────────────────────────────────────────────────
    def _domain_registration_length(self, url: str) -> int:
        """
        Suspicious TLD or very short domain lifetime signal.
        Uses TLD heuristic since whois is slow/unreliable.
        Suspicious TLD -> -1, common TLD -> 1.
        """
        try:
            netloc = urllib.parse.urlparse(url).netloc
            for tld in SUSPICIOUS_TLDS:
                if netloc.endswith(tld):
                    return -1
            return 1
        except Exception:
            return -1

    # ── Feature 10 ─────────────────────────────────────────────────────────
    def _favicon(self, url: str) -> int:
        """
        Favicon loaded from external domain = phishing.
        Without fetching the page, we use URL-based heuristics.
        Legit sites rarely have suspicious TLDs even for favicons.
        """
        if self._domain_registration_length(url) == -1:
            return -1
        return 1

    # ── Feature 11 ─────────────────────────────────────────────────────────
    def _port(self, url: str) -> int:
        """Non-standard port = phishing (-1)."""
        try:
            port = urllib.parse.urlparse(url).port
            if port is None:
                return 1
            if port in (80, 443, 8080, 8443):
                return 0
            return -1
        except Exception:
            return -1

    # ── Feature 12 ─────────────────────────────────────────────────────────
    def _https_token(self, url: str) -> int:
        """'https' appearing deceptively IN the domain name = phishing."""
        netloc = urllib.parse.urlparse(url).netloc.lower()
        return -1 if "https" in netloc else 1

    # ── Feature 13 ─────────────────────────────────────────────────────────
    def _request_url(self, url: str) -> int:
        """
        Percentage of external objects in page.
        Approximated: very long query strings / paths suggest external loads.
        <22% -> 1, 22-61% -> 0, >61% -> -1
        """
        try:
            parsed = urllib.parse.urlparse(url)
            path_q = len(parsed.path) + len(parsed.query)
            ratio = path_q / max(len(url), 1)
            if ratio < 0.22:  return 1
            if ratio < 0.61:  return 0
            return -1
        except Exception:
            return 0

    # ── Feature 14 ─────────────────────────────────────────────────────────
    def _url_of_anchor(self, url: str) -> int:
        """
        % of anchor tags with # links.
        Without page fetch, approximated by URL structure.
        URLs with many path segments tend to have external anchors.
        """
        try:
            path = urllib.parse.urlparse(url).path
            depth = path.count("/")
            if depth <= 2:  return 1
            if depth <= 4:  return 0
            return -1
        except Exception:
            return 0

    # ── Feature 15 ─────────────────────────────────────────────────────────
    def _links_in_tags(self, url: str) -> int:
        """
        Links in <meta>, <script>, <link> tags from external domains.
        Approximated: suspicious TLD implies external tag loading.
        """
        if self._domain_registration_length(url) == -1:
            return -1
        return 1

    # ── Feature 16 ─────────────────────────────────────────────────────────
    def _sfh(self, url: str) -> int:
        """
        Server Form Handler (SFH): form action pointing elsewhere.
        Approximated: POST-likely phishing URLs have action verbs.
        """
        url_l = url.lower()
        action_words = ["submit", "login", "signin", "webscr", "update",
                        "confirm", "verify", "process"]
        count = sum(w in url_l for w in action_words)
        if count >= 2: return -1
        if count == 1: return 0
        return 1

    # ── Feature 17 ─────────────────────────────────────────────────────────
    def _submitting_to_email(self, url: str) -> int:
        """'mailto:' in URL = phishing (-1)."""
        return -1 if "mailto:" in url.lower() else 1

    # ── Feature 18 ─────────────────────────────────────────────────────────
    def _abnormal_url(self, url: str) -> int:
        """
        URL doesn't include domain name in proper position (whois mismatch).
        Heuristic: IP in URL or suspicious TLD = abnormal.
        """
        if self._having_ip_address(url) == -1:
            return -1
        if self._domain_registration_length(url) == -1:
            return -1
        return 1

    # ── Feature 19 ─────────────────────────────────────────────────────────
    def _redirect(self, url: str) -> int:
        """
        Number of redirects:
          0    -> 1
          1    -> 0
          >=2  -> -1
        Approximated by '//' count beyond protocol.
        """
        count = url.count("//") - 1  # subtract the protocol //
        if count <= 0:  return 1
        if count == 1:  return 0
        return -1

    # ── Feature 20 ─────────────────────────────────────────────────────────
    def _on_mouseover(self, url: str) -> int:
        """Status bar changes onmouseover. Default 1 (safe) without page."""
        return 1

    # ── Feature 21 ─────────────────────────────────────────────────────────
    def _right_click(self, url: str) -> int:
        """Right-click disabled. Default 1 (safe) without page fetch."""
        return 1

    # ── Feature 22 ─────────────────────────────────────────────────────────
    def _popup_window(self, url: str) -> int:
        """Popup window with text fields. Default 1 (safe) without page."""
        return 1

    # ── Feature 23 ─────────────────────────────────────────────────────────
    def _iframe(self, url: str) -> int:
        """Iframe usage. Default 1 (safe). Flagged if URL is very suspicious."""
        # If multiple strong signals, guess phishing
        signals = sum([
            self._having_ip_address(url) == -1,
            self._domain_registration_length(url) == -1,
            self._prefix_suffix(url) == -1,
            self._having_sub_domain(url) == -1,
        ])
        return -1 if signals >= 3 else 1

    # ── Feature 24 ─────────────────────────────────────────────────────────
    def _age_of_domain(self, url: str) -> int:
        """
        Domain age < 6 months = phishing.
        Heuristic: suspicious TLDs are typically new.
        """
        if self._domain_registration_length(url) == -1:
            return -1
        if self._having_ip_address(url) == -1:
            return -1
        return 1

    # ── Feature 25 ─────────────────────────────────────────────────────────
    def _dns_record(self, url: str) -> int:
        """DNS resolution: success -> 1, failure -> -1."""
        try:
            domain = urllib.parse.urlparse(url).netloc.split(":")[0]
            socket.gethostbyname(domain)
            return 1
        except Exception:
            return -1

    # ── Feature 26 ─────────────────────────────────────────────────────────
    def _web_traffic(self, url: str) -> int:
        """
        Alexa rank < 100k -> 1, 100k-1M -> 0, no rank -> -1.
        Without API, approximated by domain recognition.
        """
        known_legit = [
            "google", "facebook", "amazon", "youtube", "twitter",
            "instagram", "microsoft", "apple", "wikipedia", "github",
            "linkedin", "reddit", "netflix", "yahoo", "bing", "flipkart",
            "naukri", "irctc", "sbi", "hdfc", "icici"
        ]
        try:
            netloc = urllib.parse.urlparse(url).netloc.lower()
            for brand in known_legit:
                if brand in netloc:
                    return 1
            # Unknown domain
            if self._domain_registration_length(url) == -1:
                return -1
            return 0
        except Exception:
            return 0

    # ── Feature 27 ─────────────────────────────────────────────────────────
    def _page_rank(self, url: str) -> int:
        """
        PageRank < 0.2 -> -1 (phishing), else 1.
        Heuristic: known brands = high rank, unknown suspicious TLD = low rank.
        """
        if self._web_traffic(url) == 1:   return 1
        if self._web_traffic(url) == -1:  return -1
        return 0

    # ── Feature 28 ─────────────────────────────────────────────────────────
    def _google_index(self, url: str) -> int:
        """Google indexed: yes -> 1, no -> -1. Heuristic by known domain."""
        return self._web_traffic(url)

    # ── Feature 29 ─────────────────────────────────────────────────────────
    def _links_pointing_to_page(self, url: str) -> int:
        """
        # of links pointing to page: 0 -> -1, 1-2 -> 0, >2 -> 1.
        Heuristic: known domains = many links.
        """
        wt = self._web_traffic(url)
        if wt == 1:   return 1
        if wt == 0:   return 0
        return -1

    # ── Feature 30 ─────────────────────────────────────────────────────────
    def _statistical_report(self, url: str) -> int:
        """
        Host in PhishTank/StopBadware top list.
        Heuristic: typosquatting or multiple suspicious signals.
        """
        url_l = url.lower()
        for brand, fakes in TYPOSQUAT_MAP.items():
            for fake in fakes:
                if fake in url_l:
                    return -1

        # Count strong negative signals
        strong_signals = sum([
            self._having_ip_address(url) == -1,
            self._having_at_symbol(url) == -1,
            self._prefix_suffix(url) == -1,
            self._domain_registration_length(url) == -1,
            self._ssl_final_state(url) == -1,
        ])
        if strong_signals >= 3:
            return -1
        if strong_signals >= 1:
            return 0
        return 1

    # ── Master extraction ─────────────────────────────────────────────────

    def extract_features(self, url: str) -> dict:
        """Extract all 30 UCI-aligned features from a URL."""
        if not url.startswith(("http://", "https://")):
            url = "http://" + url

        return {
            "having_IP_Address":        self._having_ip_address(url),
            "URL_Length":               self._url_length(url),
            "Shortining_Service":       self._shortining_service(url),
            "having_At_Symbol":         self._having_at_symbol(url),
            "double_slash_redirecting": self._double_slash_redirecting(url),
            "Prefix_Suffix":            self._prefix_suffix(url),
            "having_Sub_Domain":        self._having_sub_domain(url),
            "SSLfinal_State":           self._ssl_final_state(url),
            "Domain_registeration_length": self._domain_registration_length(url),
            "Favicon":                  self._favicon(url),
            "port":                     self._port(url),
            "HTTPS_token":              self._https_token(url),
            "Request_URL":              self._request_url(url),
            "URL_of_Anchor":            self._url_of_anchor(url),
            "Links_in_tags":            self._links_in_tags(url),
            "SFH":                      self._sfh(url),
            "Submitting_to_email":      self._submitting_to_email(url),
            "Abnormal_URL":             self._abnormal_url(url),
            "Redirect":                 self._redirect(url),
            "on_mouseover":             self._on_mouseover(url),
            "RightClick":               self._right_click(url),
            "popUpWidnow":              self._popup_window(url),
            "Iframe":                   self._iframe(url),
            "age_of_domain":            self._age_of_domain(url),
            "DNSRecord":                self._dns_record(url),
            "web_traffic":              self._web_traffic(url),
            "Page_Rank":                self._page_rank(url),
            "Google_Index":             self._google_index(url),
            "Links_pointing_to_page":   self._links_pointing_to_page(url),
            "Statistical_report":       self._statistical_report(url),
        }

    def extract_feature_vector(self, url: str) -> list:
        """Return features as ordered list matching UCI column order."""
        d = self.extract_features(url)
        return [d[name] for name in FEATURE_NAMES]


if __name__ == "__main__":
    fe = FeatureExtractor()
    tests = [
        "https://www.google.com",
        "http://paypa1-secure-login.verify-account.xyz/webscr?cmd=login-update",
        "http://192.168.1.1/admin",
        "https://www.amazon.com/products",
        "http://secure-banking-update.xyz/account/confirm?token=abc&session=1",
    ]
    for url in tests:
        vec = fe.extract_feature_vector(url)
        score = sum(vec)
        verdict = "LEGITIMATE" if score > 0 else "PHISHING"
        print(f"\n{url}")
        print(f"  Feature sum: {score:+d} -> {verdict}")
        features = fe.extract_features(url)
        bad = [k for k, v in features.items() if v == -1]
        if bad:
            print(f"  Suspicious : {bad}")
