"""
visualizer.py
-------------
Generate charts and graphs for model evaluation and feature analysis.
Saves all charts to the reports/ directory.
"""

import os
import io
import base64
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.metrics import confusion_matrix

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

# Dark theme palette
COLORS = {
    "phishing":    "#ff4757",
    "legitimate":  "#2ed573",
    "neutral":     "#a29bfe",
    "bg":          "#1a1a2e",
    "card":        "#16213e",
    "gradient1":   "#0f3460",
    "gradient2":   "#533483",
    "accent":      "#e94560",
    "text":        "#eee",
    "muted":       "#a0a0b0",
}


def _fig_to_base64(fig) -> str:
    """Convert matplotlib figure to base64 string for embedding in HTML."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight",
                facecolor=COLORS["bg"], dpi=120)
    buf.seek(0)
    img_b64 = base64.b64encode(buf.read()).decode("utf-8")
    plt.close(fig)
    return img_b64


def plot_confusion_matrix(y_test, y_pred, model_name: str = "Model",
                          save: bool = True) -> str:
    """Plot and return base64 confusion matrix."""
    cm = confusion_matrix(y_test, y_pred)
    labels = ["Phishing", "Legitimate"]

    fig, ax = plt.subplots(figsize=(6, 5))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["card"])

    sns.heatmap(
        cm, annot=True, fmt="d", cmap="RdYlGn",
        xticklabels=labels, yticklabels=labels,
        linewidths=2, linecolor=COLORS["bg"],
        ax=ax, cbar=True,
        annot_kws={"size": 16, "weight": "bold", "color": "white"}
    )
    ax.set_xlabel("Predicted", color=COLORS["text"], fontsize=13)
    ax.set_ylabel("Actual",    color=COLORS["text"], fontsize=13)
    ax.set_title(f"Confusion Matrix — {model_name}",
                 color=COLORS["text"], fontsize=14, pad=15)
    ax.tick_params(colors=COLORS["text"])

    if save:
        path = os.path.join(REPORTS_DIR, "confusion_matrix.png")
        fig.savefig(path, bbox_inches="tight", facecolor=COLORS["bg"], dpi=120)
        print(f"[visualizer] Saved: {path}")

    return _fig_to_base64(fig)


def plot_model_comparison(results: dict, save: bool = True) -> str:
    """Bar chart comparing model accuracies."""
    names    = list(results.keys())
    accs     = [results[n]["accuracy"]  for n in names]
    f1s      = [results[n]["f1_score"]  for n in names]
    precisions = [results[n]["precision"] for n in names]
    recalls  = [results[n]["recall"]    for n in names]

    x = np.arange(len(names))
    width = 0.2

    fig, ax = plt.subplots(figsize=(10, 6))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["card"])
    ax.set_axisbelow(True)
    ax.yaxis.grid(True, color="#333355", linewidth=0.5)

    bar1 = ax.bar(x - 1.5*width, accs,      width, label="Accuracy",  color="#2ed573", alpha=0.9, edgecolor="none")
    bar2 = ax.bar(x - 0.5*width, precisions,width, label="Precision", color="#a29bfe", alpha=0.9, edgecolor="none")
    bar3 = ax.bar(x + 0.5*width, recalls,   width, label="Recall",    color="#ffd32a", alpha=0.9, edgecolor="none")
    bar4 = ax.bar(x + 1.5*width, f1s,       width, label="F1-Score",  color="#ff4757", alpha=0.9, edgecolor="none")

    for bars in [bar1, bar2, bar3, bar4]:
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., h + 0.5,
                    f"{h:.1f}%", ha="center", va="bottom",
                    color=COLORS["text"], fontsize=8.5, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(names, color=COLORS["text"], fontsize=12)
    ax.set_ylim(0, 115)
    ax.set_ylabel("Score (%)", color=COLORS["text"], fontsize=12)
    ax.set_title("Model Performance Comparison",
                 color=COLORS["text"], fontsize=14, pad=15)
    ax.tick_params(colors=COLORS["text"])
    ax.legend(facecolor=COLORS["card"], labelcolor=COLORS["text"],
              framealpha=0.8, fontsize=10)

    if save:
        path = os.path.join(REPORTS_DIR, "model_comparison.png")
        fig.savefig(path, bbox_inches="tight", facecolor=COLORS["bg"], dpi=120)
        print(f"[visualizer] Saved: {path}")

    return _fig_to_base64(fig)


def plot_feature_importance(feature_names: list, importances: list,
                            top_n: int = 15, save: bool = True) -> str:
    """Horizontal bar chart of top feature importances."""
    sorted_idx = np.argsort(importances)[::-1][:top_n]
    top_names  = [feature_names[i].replace("_", " ").title() for i in sorted_idx]
    top_vals   = [importances[i] * 100 for i in sorted_idx]

    # Color gradient
    bar_colors = plt.cm.plasma(np.linspace(0.2, 0.9, len(top_names)))

    fig, ax = plt.subplots(figsize=(10, 7))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["card"])
    ax.set_axisbelow(True)
    ax.xaxis.grid(True, color="#333355", linewidth=0.5)

    bars = ax.barh(top_names[::-1], top_vals[::-1], color=bar_colors[::-1],
                   edgecolor="none", height=0.7)

    for bar, val in zip(bars, top_vals[::-1]):
        ax.text(bar.get_width() + 0.2, bar.get_y() + bar.get_height()/2.,
                f"{val:.1f}%", va="center", color=COLORS["text"], fontsize=9)

    ax.set_xlabel("Importance (%)", color=COLORS["text"], fontsize=12)
    ax.set_title(f"Top {top_n} Feature Importances",
                 color=COLORS["text"], fontsize=14, pad=15)
    ax.tick_params(colors=COLORS["text"])

    if save:
        path = os.path.join(REPORTS_DIR, "feature_importance.png")
        fig.savefig(path, bbox_inches="tight", facecolor=COLORS["bg"], dpi=120)
        print(f"[visualizer] Saved: {path}")

    return _fig_to_base64(fig)


def plot_dataset_distribution(labels: list, save: bool = True) -> str:
    """Donut chart of dataset class distribution."""
    phish_count = labels.count(-1)
    legit_count = labels.count(1)

    fig, ax = plt.subplots(figsize=(6, 6))
    fig.patch.set_facecolor(COLORS["bg"])
    ax.set_facecolor(COLORS["bg"])

    sizes  = [phish_count, legit_count]
    labels = ["Phishing", "Legitimate"]
    colors = [COLORS["phishing"], COLORS["legitimate"]]
    explode = (0.04, 0.04)

    wedges, texts, autotexts = ax.pie(
        sizes, labels=labels, colors=colors, explode=explode,
        autopct="%1.1f%%", startangle=90,
        wedgeprops=dict(width=0.5, edgecolor=COLORS["bg"], linewidth=3),
        textprops=dict(color=COLORS["text"]),
        pctdistance=0.75
    )
    for at in autotexts:
        at.set_fontsize(14)
        at.set_fontweight("bold")
    for t in texts:
        t.set_fontsize(13)

    ax.set_title("Dataset Class Distribution",
                 color=COLORS["text"], fontsize=14, pad=15)

    if save:
        path = os.path.join(REPORTS_DIR, "dataset_distribution.png")
        fig.savefig(path, bbox_inches="tight", facecolor=COLORS["bg"], dpi=120)
        print(f"[visualizer] Saved: {path}")

    return _fig_to_base64(fig)


if __name__ == "__main__":
    # Test with dummy data
    y_test = [-1]*50 + [1]*50
    y_pred = [-1]*45 + [1]*5 + [-1]*3 + [1]*47
    plot_confusion_matrix(y_test, y_pred)
    plot_dataset_distribution(y_test)
    print("[visualizer] Test charts generated in reports/")
