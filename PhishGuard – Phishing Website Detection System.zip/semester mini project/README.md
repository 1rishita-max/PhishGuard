# 🛡️ PhishGuard — Phishing Website Detection System

A Python-based phishing URL detection system using **Machine Learning (Random Forest)**, real-time URL analysis, and a beautiful **Flask web dashboard**.

---

## 🎯 Project Objectives
- Detect phishing URLs using ML
- Analyze 30+ suspicious URL patterns
- Improve user awareness about online threats
- Reduce the risk of online fraud

## 🛠️ Tech Stack
| Layer | Technology |
|-------|-----------|
| Language | Python 3.x |
| ML Framework | scikit-learn (Random Forest) |
| Web Framework | Flask |
| Data Processing | Pandas, NumPy |
| Visualization | Matplotlib, Seaborn |

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Train the Model (run once)
```bash
python train.py
```
This will:
- Generate a 2000-sample phishing dataset
- Train and compare 3 ML models
- Save the best model to `models/phishing_model.pkl`
- Generate analytics charts in `reports/`

### 3. Run the Web App
```bash
python app.py
```
Open **http://127.0.0.1:5000** in your browser.

---

## 📁 Project Structure
```
rishi mini project/
├── app.py                  # Flask web application
├── feature_extractor.py    # 30+ URL feature extraction
├── dataset_handler.py      # Dataset creation & preprocessing
├── ml_model.py             # ML model training & evaluation
├── predictor.py            # Real-time URL prediction
├── visualizer.py           # Charts & visualizations
├── train.py                # One-shot training pipeline
├── requirements.txt
├── datasets/
│   └── phishing_dataset.csv
├── models/
│   ├── phishing_model.pkl
│   └── scaler.pkl
├── static/css/style.css
├── static/js/main.js
├── templates/
│   ├── index.html          # Home page
│   ├── result.html         # Analysis result
│   ├── dashboard.html      # ML analytics
│   └── about.html          # Project info
└── reports/                # Auto-generated charts
```

## 🔍 Features Analyzed (30+)
- IP address in URL
- URL length & depth
- HTTPS protocol & SSL certificate
- Domain prefix/suffix tricks (`-` in domain)
- Subdomain count
- URL shortening services (bit.ly, tinyurl, etc.)
- @ symbol in URL
- Double slash redirects
- Suspicious TLDs (.xyz, .tk, .cf, etc.)
- DNS record existence
- Port number analysis
- Typosquatting detection (paypa1, g00gle, etc.)
- Sensitive keyword detection
- Encoded characters
- Query parameter count
- And many more!

## 📊 Model Performance
| Model | Accuracy |
|-------|---------|
| Random Forest | ~95%+ |
| Decision Tree | ~90%+ |
| Logistic Regression | ~88%+ |

## 💡 CLI Usage
```bash
# Test a URL directly from command line
python predictor.py --url "https://www.google.com"
python predictor.py --url "http://paypa1-secure.xyz/login"
```

## 🌐 Web API
```bash
curl -X POST http://127.0.0.1:5000/api/predict \
     -H "Content-Type: application/json" \
     -d '{"url": "https://google.com"}'
```

## Skills Applied
Python · Data Analysis · Machine Learning · Networking Basics · Logic Building · Flask Web Dev · Feature Engineering · Data Visualization
