/* main.js — PhishGuard frontend interactions */

// ─── URL Input helpers ───
function fillUrl(url) {
  const input = document.getElementById('urlInput');
  if (input) {
    input.value = url;
    input.focus();
    input.classList.add('input-flash');
    setTimeout(() => input.classList.remove('input-flash'), 600);
  }
}

// ─── Analyze form loading state ───
const analyzeForm = document.getElementById('analyzeForm');
if (analyzeForm) {
  analyzeForm.addEventListener('submit', function(e) {
    const url = document.getElementById('urlInput')?.value.trim();
    if (!url) { e.preventDefault(); return; }

    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.style.display = 'flex';

    const btn = document.getElementById('analyzeBtn');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span class="btn-text">Analyzing...</span><div class="btn-spinner"></div>';
    }
  });
}

// ─── Animate risk bar on result page ───
document.addEventListener('DOMContentLoaded', () => {
  const riskBar = document.querySelector('.risk-bar-fill');
  if (riskBar) {
    const targetWidth = riskBar.style.width;
    riskBar.style.width = '0%';
    requestAnimationFrame(() => {
      setTimeout(() => { riskBar.style.width = targetWidth; }, 100);
    });
  }

  // Animate summary numbers
  document.querySelectorAll('.sum-num').forEach(el => {
    const target = parseInt(el.textContent, 10);
    if (!isNaN(target) && target > 0) {
      animateCounter(el, target);
    }
  });

  // Animate feature rows with stagger
  document.querySelectorAll('.feat-row').forEach((row, i) => {
    row.style.opacity = '0';
    row.style.transform = 'translateX(-10px)';
    row.style.transition = `opacity 0.3s ease ${i * 0.018}s, transform 0.3s ease ${i * 0.018}s`;
    requestAnimationFrame(() => {
      setTimeout(() => {
        row.style.opacity = '1';
        row.style.transform = 'translateX(0)';
      }, 50);
    });
  });

  // Fade in feature cards
  document.querySelectorAll('.feature-card, .sum-card, .about-card, .chart-card').forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = `opacity 0.5s ease ${i * 0.07}s, transform 0.5s ease ${i * 0.07}s`;
    requestAnimationFrame(() => {
      setTimeout(() => {
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, 100);
    });
  });
});

// ─── Counter animation ───
function animateCounter(el, target, duration = 800) {
  const start = performance.now();
  const update = (now) => {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(eased * target);
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

// ─── Copy URL button (if present) ───
document.querySelectorAll('[data-copy]').forEach(btn => {
  btn.addEventListener('click', () => {
    const text = btn.getAttribute('data-copy');
    navigator.clipboard.writeText(text).then(() => {
      const orig = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = orig; }, 1500);
    });
  });
});

// ─── Keyboard shortcut: Ctrl+Enter to submit ───
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    const form = document.getElementById('analyzeForm');
    if (form) form.requestSubmit();
  }
});

// ─── Add CSS for btn-spinner inline (avoids extra CSS file changes) ───
const style = document.createElement('style');
style.textContent = `
  .btn-spinner {
    width: 16px; height: 16px;
    border: 2px solid rgba(255,255,255,0.4);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.6s linear infinite;
  }
  .input-flash { animation: flash 0.5s ease; }
  @keyframes flash {
    0%, 100% { border-color: var(--border); }
    50% { border-color: var(--primary); box-shadow: 0 0 15px rgba(124,108,248,0.4); }
  }
`;
document.head.appendChild(style);
